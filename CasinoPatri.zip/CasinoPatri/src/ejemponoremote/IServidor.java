/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemponoremote;

/**
 *
    public int buscarUsuario (Usuario persona);
 * @author CampusFP
 */
public interface IServidor {
    
    public void agregarUsuario(String nom, int dinero, int dni);
    
    public int buscarUsuario (int dni);
    
    public Usuario autentificar (String nom, int dni);
    
    public void consultarSaldo(String nombre, int dni);
    
    public void ingresar (int dinero, int dni);
    
    public void restar(int dinero, int dni);
    
    public void ganar(int dinero, int dni);
    
    public void ruleta(int apuesta, int dni);
    
	public void blackJack(int apuesta, int dni);
   
}
