/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemponoremote;

/**
 *
 * @author CampusFP
 */
public class Usuario {
    int Id;
    String nombre;
    int pasta;
    int dnii;
    
    public Usuario(){   }
    
    public Usuario (String nom, int pastaGansa, int dni){
        nombre = nom;
        Id = (int)(Math.random()*1000)+1;  //2 usuarios podrian tener el mismo id
        pasta = pastaGansa;
        dnii = dni;
    }
    
}
