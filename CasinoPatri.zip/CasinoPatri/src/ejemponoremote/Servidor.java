/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemponoremote;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author CampusFP
 */
public class Servidor implements IServidor {

	ArrayList<Usuario> clientes = new ArrayList<Usuario>();

	@Override
	public void agregarUsuario(String nom, int dinero, int dni) {
		clientes.add(new Usuario(nom, dinero, dni));
		System.out.println("\nSe ha agregado correctamente. Sus datos:\n  nombre: "
				+ clientes.get(clientes.size() - 1).nombre + "\n  Numero de cliente: "
				+ clientes.get(clientes.size() - 1).Id + "\n  Saldo: " + clientes.get(clientes.size() - 1).pasta + "�"
				+ "\n  Contrase�a: " + clientes.get(clientes.size() - 1).dnii);
	}

	@Override
	public Usuario autentificar(String nom, int dni) {
		Usuario encontrar;

		int posicion = buscarUsuario(dni);

		if (posicion != (-1)) {
			encontrar = clientes.get(posicion);
			return encontrar;
		} else {
			return null;
		}

	}

	@Override
	public void consultarSaldo(String nombre, int dni) {
		Usuario persona = autentificar(nombre, dni);

		if (persona != null) {
			System.out.println("\nEl saldo de " + persona.nombre + " es: " + persona.pasta + "�");
		} else {
			System.out.println("\nUsuario no encontrado");
		}
	}

	@Override
	public int buscarUsuario(int dni) {
		int posicion = -1;
		int contador = 0;

		for (int i = 0; i < clientes.size(); i++) {
			if (dni == clientes.get(i).dnii) {
				posicion = i;
				contador++;
			}
		}

		if (contador > 1) {
			System.out.println("Warning: Hay  mas de un usuario con la misma Id");
		}

		return posicion;
	}

	@Override
	public void ingresar(int dinero, int dni) {
		int posicion = buscarUsuario(dni);

		if (posicion != -1) {
			clientes.get(posicion).pasta += dinero;
			System.out.println("\nResume:\n  Nombre: " + clientes.get(posicion).nombre + "\n  Dinero ingresado: "
					+ dinero + "�\n  Dinero total: " + clientes.get(posicion).pasta + "�");
		} else {
			System.out.println("\nUsuario no encontrado");
		}
	}

	@Override
	public void ganar(int dinero, int dni) {
		int posicion = buscarUsuario(dni);

		if (posicion != -1) {
			clientes.get(posicion).pasta += dinero;
			System.out.println("\nResumen del juego:\n  Nombre: " + clientes.get(posicion).nombre
					+ "\n  Dinero ganado: " + dinero + "�\n  Dinero total: " + clientes.get(posicion).pasta + "�");
		} else {
			System.out.println("\nUsuario no encontrado");
		}
	}

	@Override
	public void restar(int dinero, int dni) {
		int posicion = buscarUsuario(dni);

		if (posicion != -1) {
			clientes.get(posicion).pasta -= dinero;
			System.out.println("\nResumen del juego:\n  Nombre: " + clientes.get(posicion).nombre
					+ "\n  Dinero perdido: " + dinero + "�\n  Dinero total: " + clientes.get(posicion).pasta + "�");
		} else {
			System.out.println("\nUsuario no encontrado");
		}
	}

	@Override
	public void ruleta(int apuestaR, int dni) {
		Scanner scaner = new Scanner(System.in);
		System.out.println("elige a que quieres apostar:");
		System.out.println("1.Apostar a numero simple");
		System.out.println("2.Apostar a color (rojo/negro)");
		System.out.println("3.Apostar a grupo 0,(1-12),(13-24),(25-36)");
		int aleatorio = (int) (Math.random() * 37);
		int opcion = scaner.nextInt();
		int ganancia = 0;
		switch (opcion) {
		case 1:

			System.out.println("Elige un numero del 0 al 36");
			int numero = scaner.nextInt();
			System.out.println("Ha salido el numero "+ aleatorio);
			if (numero == aleatorio) {
				System.out.println("HAS ACERTADO!");
				ganancia = apuestaR * 36;
				ganar(ganancia, dni);
			} else {
				System.out.println("Vaya, has perdido!");
				restar(apuestaR, dni);
			}

			break;
		case 2:

			System.out.println("�Qu� color apuestas?\n 1.rojo\n 2.negro");
			int color = scaner.nextInt();
			
			int cr = (int) (Math.random() * 2)+1;
			if (cr ==1) {
				System.out.println("HA SALIDO ROJO!");
			}else if (cr==2) {
				System.out.println("HA SALIDO NEGRO!");
			}
			if (cr == color) {
				System.out.println("HAS ACERTADO!");
				ganancia = apuestaR * 2;
				ganar(ganancia, dni);
			} else {
				System.out.println("Vaya, has perdido!");
				restar(apuestaR, dni);
			}
			break;
		case 3:

			System.out.println("�A qu� grupo\n 0\n 1.(1-12)\n 2.(13-24)\n 3.(25-36)?");
			int grupo = scaner.nextInt();
			int grupoAleatorio=0;
			System.out.println(aleatorio);
			if (aleatorio == 0) {
				grupoAleatorio = 0;
			} else if (aleatorio >= 1 && aleatorio <= 12) {
				grupoAleatorio = 1;
			} else if (aleatorio >= 13 && aleatorio <= 24) {
				grupoAleatorio = 2;
			}else if (aleatorio >= 25 && aleatorio <= 36) {
				grupoAleatorio = 3;
			}
			
			System.out.println("HA SALIDO EL NUMERO: " + aleatorio + "QUE PERTENECE AL GRUPO: " + grupoAleatorio);
			if (grupoAleatorio == grupo) {
				System.out.println("HAS ACERTADO!");
				ganancia = apuestaR * 3;
				ganar(ganancia, dni);
			} else {
				System.out.println("Vaya, has perdido!");
				restar(apuestaR, dni);
			}
		}
	}

	@Override
	public void blackJack(int apuesta, int dni) {
		Scanner entrada = new Scanner(System.in);
		String respuesta = "si";
		int total = 0;
		do {
			int aleatorio = (int) (Math.random() * 12 + 1);
			if (aleatorio == 11 || aleatorio == 12 || aleatorio == 13) {
				aleatorio = 10;
			}
			total += aleatorio;
			System.out.println("Ha salido: " + aleatorio);
			System.out.println("LLevas: " + total);
			if (total > 21) {
				System.out.println("Perdiste");
				restar(apuesta, dni);
				break;
			}
			System.out.println("�Quieres carta?");
			respuesta = entrada.nextLine();
		} while (respuesta.equals("si"));

		int totalMaquina = 0;
		do {
			int aleatorio = (int) (Math.random() * 12 + 1);
			totalMaquina += aleatorio;
		} while (totalMaquina < 17);
		System.out.println("La maquina ha sacado: " + totalMaquina);
		System.out.println("Tu tenias: " + total);
		if (total <= 21 && totalMaquina <= 21) {
			if (total > totalMaquina) {
				System.out.println("Has ganado a la maquina duplicas tu apuesta!");
				ganar(apuesta * 2, dni);
			} else if (total == totalMaquina) {
				System.out.println("EMPATE, recuperas tu apuesta");
				// no haces nada porque recuperas el dinero pero no lo restas previamente
				// entonces te quedas como estas
			} else if (total == 21) {
				System.out.println("HAS HECHO BLACK JACK, TRIPLICAS TU APUESTA!");
				ganar(apuesta * 3, dni);
			} else if (total < totalMaquina) {
				System.out.println("Ha ganado la maquina pierdes tu apuesta!");
				restar(apuesta, dni);
			}
		} else if (totalMaquina > 21 && total <= 21) {
			System.out.println("Has ganado a la maquina duplicas tu apuesta!");
			ganar(apuesta * 2, dni);
		}
	}

}
