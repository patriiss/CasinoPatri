/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemponoremote;

import java.util.Scanner;

/**
 *
 * @author CampusFP
 */
public class EjempoNoRemote {

	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {
		// TODO code application logic here

		// suponemos que esto es el cliente
		Scanner entrada = new Scanner(System.in);

		IServidor aux = new Servidor();

		int opcion, dinero, id, dni;
		String nombre;

		System.out.println("Bienvenido al Casino Patri.");

		do {
			System.out.println(
					"\nQue operacion desea realizar:\n  1: Agregar Usuario.\n  2: Consultar Saldo.\n  3: Ingresar Dinero.\n  4: Ruleta.\n  5: Black Jack.\n  6: Salir.");
			opcion = entrada.nextInt();

			switch (opcion) {
			case 1:
				System.out.println("\nCual es su nombre?");
				entrada.nextLine();
				nombre = entrada.nextLine();
				System.out.println("Cuanto dinero vas a meter en el casino?");
				dinero = entrada.nextInt();
				System.out.println("Cual es su dni?(sin la letra)");
				dni = entrada.nextInt();

				aux.agregarUsuario(nombre, dinero, dni);

				break;

			case 2:
				System.out.println("\nCual es su nombre?");
				entrada.nextLine();
				nombre = entrada.nextLine();
				System.out.println("Cual es su dni?(sin la letra)");
				dni = entrada.nextInt();

				aux.consultarSaldo(nombre, dni);

				break;

			case 3:
				System.out.println("\nCual es su nombre?");
				entrada.nextLine();
				entrada.nextLine();
				System.out.println("Cual es su dni?(sin la letra)");
				dni = entrada.nextInt();
				System.out.println("Cuanto dinero desea ingresar en su cuenta?");
				dinero = entrada.nextInt();

				aux.ingresar(dinero, dni);

				break;

			case 4:
				System.out.println("\nCual es su nombre?");
				entrada.nextLine();
				entrada.nextLine();
				System.out.println("Cual es su dni?(sin la letra)");
				dni = entrada.nextInt();

				System.out.println("�Cuanto dinero quieres apostar?");
				int apuestaR = entrada.nextInt();
				aux.ruleta(apuestaR, dni);

				break;

			case 5:
				System.out.println("\nCual es su nombre?");
				entrada.nextLine();
				entrada.nextLine();
				System.out.println("Cual es su dni?(sin la letra)");
				dni = entrada.nextInt();

				System.out.println("�Cuanto dinero quieres apostar?");
				int apuesta = entrada.nextInt();
				aux.blackJack(apuesta, dni);
				break;

			case 6:
				System.exit(0);
				break;
			}
		} while (opcion != 6);
	}

}
